chrome.runtime.onInstalled.addListener(() => {
  console.log("Camp Hollow Product Booker Extension installed!");
});
