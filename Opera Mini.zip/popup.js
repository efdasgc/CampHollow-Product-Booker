document.addEventListener("DOMContentLoaded", () => {
  const bookmarksList = document.getElementById("bookmarks");

  // Load bookmarks
  chrome.storage.local.get(["bookmarks"], (result) => {
    const bookmarks = result.bookmarks || [];
    bookmarks.forEach((bookmark) => {
      const listItem = document.createElement("li");
      const link = document.createElement("a");
      link.href = bookmark.url;
      link.textContent = bookmark.title;
      link.target = "_blank";
      listItem.appendChild(link);
      bookmarksList.appendChild(listItem);
    });
  });

  // Add current page to bookmarks
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const activeTab = tabs[0];
    const bookmarkButton = document.createElement("button");
    bookmarkButton.textContent = "Bookmark This Page";

    bookmarkButton.addEventListener("click", () => {
      const newBookmark = { title: activeTab.title, url: activeTab.url };

      chrome.storage.local.get(["bookmarks"], (result) => {
        const bookmarks = result.bookmarks || [];
        bookmarks.push(newBookmark);
        chrome.storage.local.set({ bookmarks }, () => {
          alert("Page bookmarked!");
          location.reload();
        });
      });
    });

    bookmarksList.parentNode.insertBefore(bookmarkButton, bookmarksList);
  });
});
